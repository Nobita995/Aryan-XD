<h1 align="center">Megumin Bot - MD 💥</h1>
 <p align="center">💣 WhatsApp Bot Node-Js.</p>
</p>

[![Typing SVG](https://readme-typing-svg.demolab.com?font=Fira+Code&pause=1000&color=FF0000&lines=Bienvenido+al+Repositorio;Megumin+-+Bot+-+MD;Gracias+por+preferirnos;Creado+por+David+Chian;💥+BOOM!!!;🔥)](https://git.io/typing-svg)
![Megumin](https://telegra.ph/file/b8170842d84523340c674.jpg)

---

### **`❕️ Información importante`**

<details>
 <summary><b> 🌹 Info Aquí</b></summary>

* **Este proyecto no ofrece soporte oficial para su uso en Termux.** Termux es una aplicación de terminal para Android y, aunque puede ser utilizada para ejecutar diversos programas, **este proyecto no está diseñado ni probado específicamente para funcionar en Termux**. Por lo tanto, **no garantizamos compatibilidad ni soporte técnico en este entorno**.

</details>

<details>
 <summary><b> 🌹 Info Bot</b></summary>

* Este proyecto **no está afiliado de ninguna manera** con `WhatsApp`, `Inc. WhatsApp` es una marca registrada de `WhatsApp LLC`, y este bot es un **desarrollo independiente** que **no tiene ninguna relación oficial con la compañía**.

</details>

<details>
 <summary><b> 🌹 Info V 3.0.2</b></summary>

* 📢 USER DE TERMUX
💥 Para los usuarios que intentan instalar el bot vía la aplicación **`termux`**, tenemos esta noticia.

* 💥 El staff de **`MeguminBot`** da aviso a los usuarios de **`Termux`** que ya no es posible instalar el Bot debido a las actualizaciones y los últimos commits realizados por el equipo del bot

* 💥 como tal más, esto se ah removido del repositorio oficial como tal, aquel usuario que intente instalar, deberá tener en cuenta que ya no se brindará soporte ni ya es instalable.

> 💥 **`Gracias por visitar el repositorio MeguminBot`**

</details>

---

### **`💭 Contáctanos`**

<details>
<summary><b> 💣 Contáctos</b></summary>

* themeguminbot@gmail.com
* https://wa.me/573218138672
* https://wa.me/5351524614

</details>

---

#### **`💣 Instalación por cloudshell`**

<details>
 <summary><b> 💥 Comandos</b></summary>

[![blog](https://img.shields.io/badge/Video-Tutorial-FF0000?style=for-the-badge&logo=youtube&logoColor=white)
](https://youtu.be/175OipZkeLQ?si=8fbNFwaXqMG6XXt)

[`💥 Instalar Cloud Shell Clic Aqui`](https://www.mediafire.com/file/bp2l6cci2p30hjv/Cloud+Shell_1.apk/file)

```bash
> git clone https://github.com/David-Chian/Megumin-Bot-MD
```

```bash
> cd Megumin-Bot-MD && yarn install
```

```bash
> npm install
```

```bash
> npm start
```

</details>

---

#### **`🌌 ACTIVAR EN CODESPACE`**

[![Open in GitHub Codespaces](https://github.com/codespaces/badge.svg)](https://github.com/codespaces/new?skip_quickstart=true&machine=basicLinux32gb&repo=David-Chian/Megumin-Bot-MD&ref=main&geo=UsEast)

----- 
#### **`⏏️ ACTIVAR EN KOYEB`**
[![Deploy to Koyeb](https://binbashbanana.github.io/deploy-buttons/buttons/remade/koyeb.svg)](https://app.koyeb.com/deploy?type=git&repository=github.com/David-Chian/Megumin-Bot-MD&branch=master&name=meguminbot-md)

------------------
#### **`☁️ ACTIVAR EN RENDER`**
[![Deploy to Render](https://binbashbanana.github.io/deploy-buttons/buttons/remade/render.svg)](https://dashboard.render.com/blueprint/new?repo=https%3A%2F%2Fgithub.com%2FDavid-Chian%2FMegumin-Bot-MD)

------------------
##### **`💻 PARA USUARIOS DE WINDOWS/VPS/RDP`**

<details>
 <summary><b> ⚡️ Comandos</b></summary>

* Descargar e instala Git [`Aquí`](https://git-scm.com/downloads)
* Descargar e instala NodeJS [`Aquí`](https://nodejs.org/en/download)
* Descargar e instala FFmpeg [`Aquí`](https://ffmpeg.org/download.html) (**No olvide agregar FFmpeg a la variable de entorno PATH**)
* Descargar e instala ImageMagick [`Aquí`](https://imagemagick.org/script/download.php)
* Descargar e instala Yarn [`Aquí`](https://classic.yarnpkg.com/en/docs/install#windows-stable)
```bash
git clone https://github.com/David-Chian/Megumin-Bot-MD && cd Megumin-Bot-MD && npm install && npm update && node .
```

</details>

##### **`💻 Instalación de FFmpeg para Windows`**

<details>
 <summary><b> ⚡️ Comandos2</b></summary>

* Descarga cualquiera de las versiones de FFmpeg disponibles haciendo clic en [FFmpeg](https://www.gyan.dev/ffmpeg/builds/).
* Extraer archivos a `C:\` path.
* Cambie el nombre de la carpeta extraída a `ffmpeg`.
* Ejecute el símbolo del sistema como administrador.
* Ejecute el siguiente comando:
```cmd
> setx /m PATH "C:\ffmpeg\bin;%PATH%"
```
Si tiene éxito, le dará un mensaje como: `SUCCESS: specified value was saved`.
* Ahora que tiene FFmpeg instalado, verifique que funcionó ejecutando este comando para ver la versión:
```cmd
> ffmpeg -version
```

</details>

---

## **`🔗 Enlaces útiles`**

| APP | TIPO | ENLACE |
|------|-------------|-------|
| WhatsApp | Canal | [¡Click aquí!](https://whatsapp.com/channel/0029VacDy0R6hENqnTKnG820) |
| WhatsApp | Canal Sunlight | [¡Click aquí!](https://whatsapp.com/channel/0029Vam7yUg77qVaz3sIAp0z) |
| WhatsApp | Gc Sunlight | [¡Click aquí!](https://chat.whatsapp.com/Fy74b6fgE9SJJpHVi6CKJY) |

---

### **`🌴 COLABORADORES`**
<a href="https://github.com/David-Chian/Megumin-Bot-MD/graphs/contributors">
<img src="https://contrib.rocks/image?repo=David-Chian/Megumin-Bot-MD" /> 
</a>

### **`👑 PROPIETARIO`**
<a
href="https://github.com/David-Chian"><img src="https://github.com/David-Chian.png" width="130" height="130" alt="David"/></a>

### **`🌹 CREDITOS`**
<a
href="https://github.com/BrunoSobrino"><img src="https://github.com/BrunoSobrino.png" width="130" height="130" alt="BrunoSobrino"/></a>

[© Powered By Sunlight Team ⚡︎](https://whatsapp.com/channel/0029Vam7yUg77qVaz3sIAp0z)